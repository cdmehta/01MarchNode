var a = 10;
var b = 20;
// b+=2; // b = b+2 //SRT
// console.log(a**5); //a exponent 2 
// var c = a < b ? a : b;
// console.log(!5 < 4);
// if (a === b)
//     console.log("A and B are Equal");
// else
//     console.log("A and B are Not Equal");
// = == ===


// String OPerator
var a="TOPS";
var b="Technologies";
var c=a+b; //add //concate
console.log(c);

