//Without Argument without return value
// function add(){
//     let a=10;
//     let b=10;
//     console.log(a+b);
// }

// With Argument without return value
// function add(a,b){
//     console.log(a+b);
// }
// add(10,20);

// Without Argument with return value
// function add(){
//     let a=10;
//     let b=30;
//     return a+b;
// }
// // var result=add();
// console.log(add());

// With Argument with return value
// function add(a,b){
//     return a+b;
// }
// // var result=add();
// console.log(add(15,16));


//function parameter
// function add(a=5,b=10){
//     return a+b;
// }
// // var result=add();
// console.log(add());


function div(a,b=1){
    return a/b;
}
console.log(div(8));


// add();
// var-- global  let const -- local
// 2 category
// 1. Built In
// 2. UDF