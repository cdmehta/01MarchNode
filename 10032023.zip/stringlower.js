// TOPS
// tops
// without using toLowerCase
var s="ABC";
// console.log(s.toLowerCase());
for(let i=0;i<s.length;i++)
{
    var a=s.charCodeAt(i);
    if(a>=65 && a<=90){
        a+=32;
        console.log(String.fromCharCode(a));
    }

    
}
